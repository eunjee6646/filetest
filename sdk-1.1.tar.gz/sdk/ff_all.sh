# linux
fastboot flash dtb_linux  linux/dtb.img
fastboot flash dtbo_linux  linux/dtbo.img
#fastboot flash rootfs -S 512M linux/core-image-bare-euto-v9-discovery-sparse.ext4

# usbboot

fastboot erase env

fastboot reboot
